<?php


$apikey = "eyemrefreeJpc3MiOiJ0b3B0YWwuY29tIiwiGXhwIjoxNDI2NDIwODAwLCJodHwdGFsLmNvbS9qd21wYW55IioiVGJ1ZzX1";

$i_id = "54114258463";

$dID = "4f3b19dee61d1569";
